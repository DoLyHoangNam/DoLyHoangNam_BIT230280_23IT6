﻿using System;
using System.Collections.Generic;

namespace DictionaryExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> dict1;
            dict1 = new Dictionary<string, string>();
            dict1["Nam"] = "1A";
            dict1["Lan"] = "2B";
            dict1.Add("Mai", "3C");
            foreach (var item in dict1)
            {
                Console.WriteLine(item.Key.ToString());
            }
        }
    }
}