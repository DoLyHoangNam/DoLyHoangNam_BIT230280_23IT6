﻿using System;
using System.Collections.Generic;

namespace DictionaryExample
{
    class Bai51Chuong7
    {
        static void Main(string[] args)
        {
            // Section 1: Implicitly Typed Variable
            var i = 1;
            Console.WriteLine("Implicitly typed variable i: " + i);

            // Section 2: Initialize and Populate Dictionary
            var dict1 = new Dictionary<int, string>();
            dict1[3] = "Nam";
            dict1[8] = "Lan";
            dict1.Add(7, "Mai");

            // Section 3: Iterating Through Dictionary Using KeyValuePair
            Console.WriteLine("\nIterating through dictionary with KeyValuePair:");
            foreach (KeyValuePair<int, string> item in dict1)
            {
                Console.WriteLine(item.Key.ToString() + ": " + item.Value);
            }

            // Section 4: Iterating Through Dictionary Using var
            Console.WriteLine("\nIterating through dictionary with var:");
            foreach (var item in dict1)
            {
                Console.WriteLine(item.Key.ToString() + ": " + item.Value);
            }

            // Section 5: Adding More Elements Using Add Method
            dict1.Add(9, "Phuc");
            dict1.Add(10, "Hieu");

            // Display Dictionary After Adding More Elements
            Console.WriteLine("\nDictionary after adding more elements:");
            foreach (var item in dict1)
            {
                Console.WriteLine(item.Key.ToString() + ": " + item.Value);
            }

            // Section 6: Iterating Through Keys Only
            Console.WriteLine("\nIterating through keys:");
            foreach (var key in dict1.Keys)
            {
                Console.WriteLine(key.ToString());
            }

            // Section 7: Iterating Through Values Only
            Console.WriteLine("\nIterating through values:");
            foreach (var val in dict1.Values)
            {
                Console.WriteLine(val.ToString());
            }
        }
    }
}
